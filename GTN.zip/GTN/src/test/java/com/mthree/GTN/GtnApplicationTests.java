package com.mthree.GTN;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GtnApplicationTests {

	@Test
	void contextLoads() {
	}

}
